# ecom-website

To Understand the code.
First clone the project.

After cloning try opening index.html in browser.
The UI is self explanatory.

We have used event bubbling to capture Events.

